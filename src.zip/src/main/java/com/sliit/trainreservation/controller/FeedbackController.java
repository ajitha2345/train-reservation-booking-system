//.
package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.Feedback;
import com.sliit.trainreservation.model.FeedbackType;
import com.sliit.trainreservation.model.User;
import com.sliit.trainreservation.repository.FeedbackRepository;
import com.sliit.trainreservation.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Function 5: Customer Support and Feedback.
 *
 * Two kinds of entries share the same table:
 *  - FEEDBACK: a star rating + message. Visible to any logged-in passenger on /feedback
 *              (each passenger sees their own listed first, then everyone else's).
 *  - TICKET:   a private question visible only to the passenger who raised it and to staff.
 *
 * Once support/admin has replied to either kind, the passenger's copy is locked
 * (no further edit/delete) so the reply always matches what was actually asked.
 */
@Controller
public class FeedbackController {

    private final FeedbackRepository feedbackRepository;
    private final UserService userService;

    public FeedbackController(FeedbackRepository feedbackRepository, UserService userService) {
        this.feedbackRepository = feedbackRepository;
        this.userService = userService;
    }

    // ------------------------------------------------------------------
    // Passenger: public feedback + ratings
    // ------------------------------------------------------------------

    @GetMapping("/feedback")
    public String form(Authentication authentication, Model model) {
        User passenger = userService.findByEmail(authentication.getName());
        model.addAttribute("myFeedback",
                feedbackRepository.findByPassengerAndTypeOrderBySubmittedAtDesc(passenger, FeedbackType.FEEDBACK));
        model.addAttribute("myTickets",
                feedbackRepository.findByPassengerAndTypeOrderBySubmittedAtDesc(passenger, FeedbackType.TICKET));
        // Other passengers' public feedback & ratings - visible to any logged-in user.
        // Tickets are never included here; they stay private to their author and to staff.
        model.addAttribute("otherFeedback",
                feedbackRepository.findByTypeAndPassengerNotOrderBySubmittedAtDesc(FeedbackType.FEEDBACK, passenger));
        return "feedback";
    }

    @PostMapping("/feedback")
    public String submit(@RequestParam String message,
                         @RequestParam int rating,
                         Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback feedback = new Feedback();
        feedback.setPassenger(passenger);
        feedback.setMessage(message);
        feedback.setRating(clampRating(rating));
        feedback.setType(FeedbackType.FEEDBACK);
        feedbackRepository.save(feedback);
        return "redirect:/feedback?submitted";
    }

    // UPDATE: passenger edits their own feedback (message + rating).
    // Owner-only, and locked once support has replied.
    @PostMapping("/feedback/{id}/update")
    public String updateFeedback(@PathVariable Long id,
                                 @RequestParam String message,
                                 @RequestParam int rating,
                                 Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback feedback = feedbackRepository.findById(id).orElseThrow();

        if (isOwnedByAndEditable(feedback, passenger)) {
            feedback.setMessage(message);
            feedback.setRating(clampRating(rating));
            feedbackRepository.save(feedback);
        }
        return "redirect:/feedback";
    }

    // DELETE: passenger removes their own feedback. Owner-only, locked once replied.
    @PostMapping("/feedback/{id}/delete")
    public String deleteFeedback(@PathVariable Long id, Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback feedback = feedbackRepository.findById(id).orElseThrow();

        if (isOwnedByAndEditable(feedback, passenger)) {
            feedbackRepository.delete(feedback);
        }
        return "redirect:/feedback";
    }

    // ------------------------------------------------------------------
    // Passenger: private support tickets (one-on-one with admin/support)
    // ------------------------------------------------------------------

    @PostMapping("/tickets")
    public String raiseTicket(@RequestParam String message, Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback ticket = new Feedback();
        ticket.setPassenger(passenger);
        ticket.setMessage(message);
        ticket.setType(FeedbackType.TICKET);
        feedbackRepository.save(ticket);
        return "redirect:/feedback?ticketSubmitted";
    }

    // UPDATE: passenger edits their own ticket question. Owner-only, locked once replied.
    @PostMapping("/tickets/{id}/update")
    public String updateTicket(@PathVariable Long id,
                               @RequestParam String message,
                               Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback ticket = feedbackRepository.findById(id).orElseThrow();

        if (isOwnedByAndEditable(ticket, passenger)) {
            ticket.setMessage(message);
            feedbackRepository.save(ticket);
        }
        return "redirect:/feedback";
    }

    // DELETE: passenger removes their own ticket. Owner-only, locked once replied.
    @PostMapping("/tickets/{id}/delete")
    public String deleteTicket(@PathVariable Long id, Authentication authentication) {
        User passenger = userService.findByEmail(authentication.getName());
        Feedback ticket = feedbackRepository.findById(id).orElseThrow();

        if (isOwnedByAndEditable(ticket, passenger)) {
            feedbackRepository.delete(ticket);
        }
        return "redirect:/feedback";
    }

    // ------------------------------------------------------------------
    // Support / Admin
    // ------------------------------------------------------------------

    @GetMapping("/support/feedback")
    public String allFeedback(Model model) {
        model.addAttribute("feedbackList", feedbackRepository.findByTypeOrderBySubmittedAtDesc(FeedbackType.FEEDBACK));
        model.addAttribute("ticketList", feedbackRepository.findByTypeOrderBySubmittedAtDesc(FeedbackType.TICKET));
        return "admin/feedback-list";
    }

    // Works for both feedback and tickets - the id alone identifies the record.
    @PostMapping("/support/feedback/{id}/respond")
    public String respond(@PathVariable Long id, @RequestParam String response) {
        Feedback feedback = feedbackRepository.findById(id).orElseThrow();
        feedback.setResponse(response);
        feedback.setResolved(true);
        feedbackRepository.save(feedback);
        return "redirect:/support/feedback";
    }

    // UPDATE: admin edits their existing reply.
    @PostMapping("/support/feedback/{id}/response/update")
    public String updateResponse(@PathVariable Long id, @RequestParam String response) {
        Feedback feedback = feedbackRepository.findById(id).orElseThrow();
        feedback.setResponse(response);
        feedbackRepository.save(feedback);
        return "redirect:/support/feedback";
    }

    // DELETE: admin removes their reply, reopening the ticket for a fresh response
    // (and unlocking it again for the passenger to edit).
    @PostMapping("/support/feedback/{id}/response/delete")
    public String deleteResponse(@PathVariable Long id) {
        Feedback feedback = feedbackRepository.findById(id).orElseThrow();
        feedback.setResponse(null);
        feedback.setResolved(false);
        feedbackRepository.save(feedback);
        return "redirect:/support/feedback";
    }

    // DELETE: admin removes an entire feedback/ticket entry (moderation).
    @PostMapping("/support/feedback/{id}/delete")
    public String deleteFeedbackAsAdmin(@PathVariable Long id) {
        feedbackRepository.deleteById(id);
        return "redirect:/support/feedback";
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private boolean isOwnedByAndEditable(Feedback feedback, User passenger) {
        return feedback.getPassenger().getId().equals(passenger.getId()) && !feedback.isResolved();
    }

    private int clampRating(int rating) {
        return Math.max(1, Math.min(5, rating));
    }
}
