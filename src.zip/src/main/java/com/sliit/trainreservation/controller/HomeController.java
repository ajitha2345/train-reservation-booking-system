package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.User;
import com.sliit.trainreservation.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final UserService userService;

    public HomeController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String index() {
        return "index"; // Loads the new role selection landing page
    }

    @GetMapping("/home")
    public String home(Authentication authentication, Model model) {
        User user = userService.findByEmail(authentication.getName());
        model.addAttribute("fullName", user.getFullName());
        return "home";
    }
}

