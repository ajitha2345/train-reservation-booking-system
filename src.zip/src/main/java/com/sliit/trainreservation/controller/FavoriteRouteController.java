package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.FavoriteRoute;
import com.sliit.trainreservation.model.Schedule;
import com.sliit.trainreservation.model.SeatClass;
import com.sliit.trainreservation.model.Station;
import com.sliit.trainreservation.model.User;
import com.sliit.trainreservation.repository.FavoriteRouteRepository;
import com.sliit.trainreservation.repository.StationRepository;
import com.sliit.trainreservation.service.ScheduleService;
import com.sliit.trainreservation.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/favorites")
public class FavoriteRouteController {

    private final FavoriteRouteRepository favoriteRouteRepository;
    private final StationRepository stationRepository;
    private final ScheduleService scheduleService;
    private final UserService userService;

    public FavoriteRouteController(FavoriteRouteRepository favoriteRouteRepository,
                                   StationRepository stationRepository,
                                   ScheduleService scheduleService,
                                   UserService userService) {
        this.favoriteRouteRepository = favoriteRouteRepository;
        this.stationRepository = stationRepository;
        this.scheduleService = scheduleService;
        this.userService = userService;
    }

    // READ: view saved routes, each with its upcoming scheduled trips attached
    @GetMapping
    public String viewFavorites(Authentication authentication, Model model) {
        User user = userService.findByEmail(authentication.getName());
        List<FavoriteRoute> favorites = favoriteRouteRepository.findByUser(user);

        // Build routeId -> list of upcoming schedules, so the page can show
        // "here's what's actually running on this route" without a search form.
        Map<Long, List<Schedule>> scheduleMap = new HashMap<>();
        for (FavoriteRoute fav : favorites) {
            if (fav.getOriginStation() != null && fav.getDestinationStation() != null) {
                scheduleMap.put(fav.getId(), scheduleService.findUpcomingByRoute(
                        fav.getOriginStation().getId(), fav.getDestinationStation().getId()));
            }
        }

        model.addAttribute("favorites", favorites);
        model.addAttribute("favoriteSchedules", scheduleMap);
        model.addAttribute("stations", stationRepository.findAll());
        model.addAttribute("seatClasses", SeatClass.values());
        return "favorites";
    }

    // CREATE: save a new favorite route by picking real stations
    @PostMapping("/add")
    public String addFavorite(@RequestParam Long originStationId,
                              @RequestParam Long destinationStationId,
                              Authentication authentication,
                              RedirectAttributes redirectAttributes) {
        if (originStationId.equals(destinationStationId)) {
            redirectAttributes.addFlashAttribute("error",
                    "Origin and destination stations can't be the same.");
            return "redirect:/favorites";
        }

        User user = userService.findByEmail(authentication.getName());
        Station origin = stationRepository.findById(originStationId)
                .orElseThrow(() -> new IllegalArgumentException("Origin station not found"));
        Station destination = stationRepository.findById(destinationStationId)
                .orElseThrow(() -> new IllegalArgumentException("Destination station not found"));

        FavoriteRoute favoriteRoute = new FavoriteRoute();
        favoriteRoute.setUser(user);
        favoriteRoute.setOriginStation(origin);
        favoriteRoute.setDestinationStation(destination);
        favoriteRouteRepository.save(favoriteRoute);
        return "redirect:/favorites";
    }

    // UPDATE: change which stations a saved route points to
    @PostMapping("/update/{id}")
    public String updateFavorite(@PathVariable Long id,
                                 @RequestParam Long originStationId,
                                 @RequestParam Long destinationStationId,
                                 Authentication authentication,
                                 RedirectAttributes redirectAttributes) {
        if (originStationId.equals(destinationStationId)) {
            redirectAttributes.addFlashAttribute("error",
                    "Origin and destination stations can't be the same.");
            return "redirect:/favorites";
        }

        User user = userService.findByEmail(authentication.getName());
        FavoriteRoute route = favoriteRouteRepository.findById(id).orElseThrow();

        if (route.getUser().getId().equals(user.getId())) {
            Station origin = stationRepository.findById(originStationId)
                    .orElseThrow(() -> new IllegalArgumentException("Origin station not found"));
            Station destination = stationRepository.findById(destinationStationId)
                    .orElseThrow(() -> new IllegalArgumentException("Destination station not found"));
            route.setOriginStation(origin);
            route.setDestinationStation(destination);
            favoriteRouteRepository.save(route);
        }
        return "redirect:/favorites";
    }

    // DELETE: remove a favorite route
    @PostMapping("/delete/{id}")
    public String deleteFavorite(@PathVariable Long id, Authentication authentication) {
        User user = userService.findByEmail(authentication.getName());
        FavoriteRoute route = favoriteRouteRepository.findById(id).orElseThrow();

        if (route.getUser().getId().equals(user.getId())) {
            favoriteRouteRepository.delete(route);
        }
        return "redirect:/favorites";
    }
}

