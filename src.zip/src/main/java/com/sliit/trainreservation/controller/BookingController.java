package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.Booking;
import com.sliit.trainreservation.model.PaymentMethod;
import com.sliit.trainreservation.model.SeatClass;
import com.sliit.trainreservation.model.SeatRequest;
import com.sliit.trainreservation.model.TicketType;
import com.sliit.trainreservation.model.User;
import com.sliit.trainreservation.service.BookingService;
import com.sliit.trainreservation.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Function 2: Seat Reservation and Booking Management
 */
@Controller
public class BookingController {

    private final BookingService bookingService;
    private final UserService userService;

    public BookingController(BookingService bookingService, UserService userService) {
        this.bookingService = bookingService;
        this.userService = userService;
    }

    @PostMapping("/bookings/create")
    public String createBooking(@RequestParam Long scheduleId,
                                @RequestParam SeatClass seatClass,
                                @RequestParam List<Integer> seatNumbers,
                                @RequestParam List<TicketType> seatTypes,
                                @RequestParam PaymentMethod paymentMethod,
                                @RequestParam Long originId,
                                @RequestParam Long destinationId,
                                @RequestParam String date,
                                Authentication authentication,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        User passenger = userService.findByEmail(authentication.getName());

        List<SeatRequest> seatRequests = new ArrayList<>();
        for (int i = 0; i < seatNumbers.size(); i++) {
            seatRequests.add(new SeatRequest(seatNumbers.get(i), seatTypes.get(i)));
        }

        try {
            var booking = bookingService.createBooking(passenger, scheduleId, seatClass, seatRequests, paymentMethod);
            model.addAttribute("bookings", List.of(booking));
            model.addAttribute("totalAmount", booking.getPayment() != null ? booking.getPayment().getAmount() : 0.0);
            return "booking-confirmation";
        } catch (IllegalStateException | IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/trains/results?originId=" + originId + "&destinationId=" + destinationId + "&date=" + date;
        }
    }

    // Lets a passenger pick seats across several classes (e.g. FIRST and
    // THIRD) on the same schedule and book them all in one submit. The
    // front-end sends three parallel arrays - seatClasses[i]/seatNumbers[i]/
    // seatTypes[i] together describe one selected seat - which are grouped
    // back into per-class requests here before handing off to the service,
    // which books every class in a single transaction.
    @PostMapping("/bookings/create-multi")
    public String createMultiClassBooking(@RequestParam Long scheduleId,
                                          @RequestParam List<SeatClass> seatClasses,
                                          @RequestParam List<Integer> seatNumbers,
                                          @RequestParam List<TicketType> seatTypes,
                                          @RequestParam PaymentMethod paymentMethod,
                                          @RequestParam Long originId,
                                          @RequestParam Long destinationId,
                                          @RequestParam String date,
                                          Authentication authentication,
                                          Model model,
                                          RedirectAttributes redirectAttributes) {
        User passenger = userService.findByEmail(authentication.getName());

        Map<SeatClass, List<SeatRequest>> seatRequestsByClass = new LinkedHashMap<>();
        for (int i = 0; i < seatNumbers.size(); i++) {
            seatRequestsByClass
                    .computeIfAbsent(seatClasses.get(i), k -> new ArrayList<>())
                    .add(new SeatRequest(seatNumbers.get(i), seatTypes.get(i)));
        }

        try {
            List<Booking> bookings = bookingService.createMultiClassBooking(passenger, scheduleId, seatRequestsByClass, paymentMethod);
            double total = 0.0;
            for (Booking booking : bookings) {
                if (booking.getPayment() != null) {
                    total += booking.getPayment().getAmount();
                }
            }
            model.addAttribute("bookings", bookings);
            model.addAttribute("totalAmount", total);
            return "booking-confirmation";
        } catch (IllegalStateException | IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/trains/results?originId=" + originId + "&destinationId=" + destinationId + "&date=" + date;
        }
    }

    @GetMapping("/bookings/my")
    public String myBookings(Authentication authentication, Model model) {
        User passenger = userService.findByEmail(authentication.getName());
        model.addAttribute("bookings", bookingService.findByPassenger(passenger));
        return "my-bookings";
    }

    @PostMapping("/bookings/{id}/cancel")
    public String cancelBooking(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(authentication.getName());
        try {
            bookingService.cancelBooking(id, user);
        } catch (IllegalStateException | IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/bookings/my";
    }

    // Shows the same kind of seat picker used when booking, but scoped to
    // this one booking's schedule/class, with its current seats pre-selected
    // and excluded from the "occupied" set so the passenger can keep them.
    @GetMapping("/bookings/{id}/edit")
    public String editBookingForm(@PathVariable Long id, Authentication authentication, Model model, RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(authentication.getName());
        Booking booking = bookingService.findById(id).orElse(null);

        if (booking == null || !booking.getPassenger().getId().equals(user.getId())) {
            redirectAttributes.addFlashAttribute("error", "Booking not found.");
            return "redirect:/bookings/my";
        }
        if (!booking.isEditable()) {
            redirectAttributes.addFlashAttribute("error",
                    "This booking can no longer be edited - changes must be made at least "
                            + Booking.EDIT_CUTOFF_DAYS + " day(s) before departure.");
            return "redirect:/bookings/my";
        }

        var schedule = booking.getSchedule();
        SeatClass seatClass = booking.getSeatClass();

        List<Integer> allOccupied = bookingService.getOccupiedSeatNumbers(schedule.getId(), seatClass);
        int capacity = schedule.getSeatsFor(seatClass) + allOccupied.size();

        // This booking's own seats shouldn't show as "taken" - the passenger
        // is allowed to keep or change them.
        Set<Integer> ownSeatNumbers = new HashSet<>();
        Map<Integer, TicketType> currentSelections = new LinkedHashMap<>();
        for (var seat : booking.getSeats()) {
            ownSeatNumbers.add(seat.getSeatNumber());
            currentSelections.put(seat.getSeatNumber(), seat.getTicketType());
        }
        Set<Integer> occupiedForOthers = new HashSet<>(allOccupied);
        occupiedForOthers.removeAll(ownSeatNumbers);

        model.addAttribute("booking", booking);
        model.addAttribute("schedule", schedule);
        model.addAttribute("seatClass", seatClass);
        model.addAttribute("seatCapacity", capacity);
        model.addAttribute("occupiedSeats", occupiedForOthers);
        model.addAttribute("currentSelections", currentSelections);
        model.addAttribute("fareAdult", schedule.getFareFor(seatClass));
        model.addAttribute("fareChild", schedule.getChildFareFor(seatClass));
        return "booking-edit";
    }

    @PostMapping("/bookings/{id}/edit")
    public String editBooking(@PathVariable Long id,
                              @RequestParam List<Integer> seatNumbers,
                              @RequestParam List<TicketType> seatTypes,
                              Authentication authentication,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(authentication.getName());

        List<SeatRequest> seatRequests = new ArrayList<>();
        for (int i = 0; i < seatNumbers.size(); i++) {
            seatRequests.add(new SeatRequest(seatNumbers.get(i), seatTypes.get(i)));
        }

        try {
            Booking booking = bookingService.updateBookingSeats(id, user, seatRequests);
            model.addAttribute("bookings", List.of(booking));
            model.addAttribute("totalAmount", booking.getPayment() != null ? booking.getPayment().getAmount() : 0.0);
            model.addAttribute("edited", true);
            return "booking-confirmation";
        } catch (IllegalStateException | IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/bookings/" + id + "/edit";
        }
    }
}
