package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.Schedule;
import com.sliit.trainreservation.model.SeatClass;
import com.sliit.trainreservation.repository.StationRepository;
import com.sliit.trainreservation.service.BookingService;
import com.sliit.trainreservation.service.ScheduleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Function 1: Train Search and Schedule Viewing
 */
@Controller
public class TrainController {

    private final ScheduleService scheduleService;
    private final StationRepository stationRepository;
    private final BookingService bookingService;

    public TrainController(ScheduleService scheduleService, StationRepository stationRepository, BookingService bookingService) {
        this.scheduleService = scheduleService;
        this.stationRepository = stationRepository;
        this.bookingService = bookingService;
    }

    @GetMapping("/trains/search")
    public String searchForm(Model model) {
        model.addAttribute("stations", stationRepository.findAll());
        return "train-search";
    }

    @GetMapping("/trains/results")
    public String results(@RequestParam Long originId,
                          @RequestParam Long destinationId,
                          @RequestParam String date,
                          Model model) {
        List<Schedule> schedules = scheduleService.search(originId, destinationId, LocalDate.parse(date));
        model.addAttribute("schedules", schedules);
        model.addAttribute("seatClasses", SeatClass.values());

        // Echoed back into hidden form fields so a failed booking can redirect
        // straight back to this same search instead of losing the result page.
        model.addAttribute("originId", originId);
        model.addAttribute("destinationId", destinationId);
        model.addAttribute("date", date);

        // Seat-map data for each schedule/class combo, keyed "scheduleId-CLASS"
        // so the template can look each one up per row without extra queries.
        Map<String, Integer> seatCapacities = new HashMap<>();
        Map<String, List<Integer>> occupiedSeats = new HashMap<>();
        for (Schedule schedule : schedules) {
            for (SeatClass seatClass : SeatClass.values()) {
                String key = schedule.getId() + "-" + seatClass;
                List<Integer> occupied = bookingService.getOccupiedSeatNumbers(schedule.getId(), seatClass);
                occupiedSeats.put(key, occupied);
                seatCapacities.put(key, schedule.getSeatsFor(seatClass) + occupied.size());
            }
        }
        model.addAttribute("seatCapacities", seatCapacities);
        model.addAttribute("occupiedSeats", occupiedSeats);

        return "train-results";
    }
}
