package com.sliit.trainreservation.controller;

import com.sliit.trainreservation.model.BookingStatus;
import com.sliit.trainreservation.model.Schedule;
import com.sliit.trainreservation.model.ScheduleStatus;
import com.sliit.trainreservation.model.Station;
import com.sliit.trainreservation.model.Train;
import com.sliit.trainreservation.repository.BookingRepository;
import com.sliit.trainreservation.repository.StationRepository;
import com.sliit.trainreservation.repository.TrainRepository;
import com.sliit.trainreservation.service.ScheduleService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalTime;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final StationRepository stationRepository;
    private final TrainRepository trainRepository;
    private final ScheduleService scheduleService;
    private final BookingRepository bookingRepository;

    public AdminController(StationRepository stationRepository,
                           TrainRepository trainRepository,
                           ScheduleService scheduleService,
                           BookingRepository bookingRepository) {
        this.stationRepository = stationRepository;
        this.trainRepository = trainRepository;
        this.scheduleService = scheduleService;
        this.bookingRepository = bookingRepository;
    }

    // ===== OVERVIEW =====

    @GetMapping
    public String dashboard(Model model) {
        model.addAttribute("stationCount", stationRepository.count());
        model.addAttribute("trainCount", trainRepository.count());
        model.addAttribute("scheduleCount", scheduleService.findAll().size());
        return "admin/dashboard";
    }

    // ===== STATIONS =====

    @GetMapping("/stations")
    public String stationsPage(Model model) {
        model.addAttribute("stations", stationRepository.findAll());
        return "admin/stations";
    }

    @PostMapping("/stations")
    public String addStation(@ModelAttribute Station station) {
        stationRepository.save(station);
        return "redirect:/admin/stations";
    }

    @PostMapping("/stations/{id}/update")
    public String updateStation(@PathVariable Long id, @RequestParam String name, @RequestParam String city) {
        Station station = stationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Station not found"));
        station.setName(name);
        station.setCity(city);
        stationRepository.save(station);
        return "redirect:/admin/stations";
    }

    @PostMapping("/stations/{id}/delete")
    public String deleteStation(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            stationRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            // This station is still referenced as a train's origin/destination
            // (or someone's favorite route) - MySQL blocks the delete via the
            // foreign key rather than silently breaking those references.
            redirectAttributes.addFlashAttribute("error",
                    "Can't delete this station - it's still used by a train or a saved favorite route. Update or remove those first.");
        }
        return "redirect:/admin/stations";
    }

    // ===== TRAINS =====

    @GetMapping("/trains")
    public String trainsPage(Model model) {
        model.addAttribute("trains", trainRepository.findAll());
        model.addAttribute("stations", stationRepository.findAll());
        return "admin/trains";
    }

    @PostMapping("/trains")
    public String addTrain(@ModelAttribute Train train,
                           @RequestParam(required = false) Long originStationId,
                           @RequestParam(required = false) Long destinationStationId,
                           RedirectAttributes redirectAttributes) {
        if (originStationId != null && originStationId.equals(destinationStationId)) {
            redirectAttributes.addFlashAttribute("error", "Origin and destination stations can't be the same.");
            return "redirect:/admin/trains";
        }

        if (trainRepository.existsByTrainNumberIgnoreCase(train.getTrainNumber().trim())) {
            redirectAttributes.addFlashAttribute("error",
                    "Train number " + train.getTrainNumber().trim() + " already exists. Please use a different train number.");
            return "redirect:/admin/trains";
        }
        train.setTrainNumber(train.getTrainNumber().trim());

        String seatError = validateTrainSeats(train.getFirstClassSeats(), train.getSecondClassSeats(), train.getThirdClassSeats());
        if (seatError != null) {
            redirectAttributes.addFlashAttribute("error", seatError);
            return "redirect:/admin/trains";
        }

        // totalSeats is a display-only field in the form (disabled, so it's
        // never actually submitted) - it's always derived here instead, so
        // it can't drift out of sync with the 3 class seat counts.
        train.setTotalSeats(train.getFirstClassSeats() + train.getSecondClassSeats() + train.getThirdClassSeats());
        if (originStationId != null) {
            stationRepository.findById(originStationId).ifPresent(train::setOriginStation);
        }
        if (destinationStationId != null) {
            stationRepository.findById(destinationStationId).ifPresent(train::setDestinationStation);
        }
        try {
            trainRepository.save(train);
        } catch (DataIntegrityViolationException e) {
            // Safety net: only reached if two admins add the same number at the
            // exact same moment, after the check above has already passed.
            redirectAttributes.addFlashAttribute("error",
                    "Train number " + train.getTrainNumber() + " already exists. Please use a different train number.");
        }
        return "redirect:/admin/trains";
    }

    @PostMapping("/trains/{id}/update")
    public String updateTrain(@PathVariable Long id,
                              @RequestParam String trainName,
                              @RequestParam String trainNumber,
                              @RequestParam int firstClassSeats,
                              @RequestParam int secondClassSeats,
                              @RequestParam int thirdClassSeats,
                              @RequestParam(required = false) Long originStationId,
                              @RequestParam(required = false) Long destinationStationId,
                              RedirectAttributes redirectAttributes) {
        if (originStationId != null && originStationId.equals(destinationStationId)) {
            redirectAttributes.addFlashAttribute("error", "Origin and destination stations can't be the same.");
            return "redirect:/admin/trains";
        }

        String seatError = validateTrainSeats(firstClassSeats, secondClassSeats, thirdClassSeats);
        if (seatError != null) {
            redirectAttributes.addFlashAttribute("error", seatError);
            return "redirect:/admin/trains";
        }

        if (trainRepository.existsByTrainNumberIgnoreCaseAndIdNot(trainNumber.trim(), id)) {
            redirectAttributes.addFlashAttribute("error",
                    "Train number " + trainNumber.trim() + " already exists. Please use a different train number.");
            return "redirect:/admin/trains";
        }

        Train train = trainRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Train not found"));
        train.setTrainName(trainName);
        train.setTrainNumber(trainNumber.trim());
        train.setFirstClassSeats(firstClassSeats);
        train.setSecondClassSeats(secondClassSeats);
        train.setThirdClassSeats(thirdClassSeats);
        // Same reasoning as addTrain: always derived, never taken from the client.
        train.setTotalSeats(firstClassSeats + secondClassSeats + thirdClassSeats);
        if (originStationId != null) {
            stationRepository.findById(originStationId).ifPresent(train::setOriginStation);
        }
        if (destinationStationId != null) {
            stationRepository.findById(destinationStationId).ifPresent(train::setDestinationStation);
        }
        try {
            trainRepository.save(train);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error",
                    "Train number " + trainNumber.trim() + " already exists. Please use a different train number.");
        }
        return "redirect:/admin/trains";
    }

    // Returns an error message if the seat counts aren't valid, or null if
    // they're fine. Train.totalSeats must be positive and each class count
    // can't be negative - without this check, saving 0 seats everywhere
    // fails bean validation inside save() and ends up as an error page.
    private String validateTrainSeats(int firstClassSeats, int secondClassSeats, int thirdClassSeats) {
        if (firstClassSeats < 0 || secondClassSeats < 0 || thirdClassSeats < 0) {
            return "Seat counts can't be negative.";
        }
        if (firstClassSeats + secondClassSeats + thirdClassSeats <= 0) {
            return "A train needs at least 1 seat. Enter seats for at least one class.";
        }
        return null;
    }

    @PostMapping("/trains/{id}/delete")
    public String deleteTrain(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            trainRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            // This train still has schedules (or other records) pointing at it -
            // MySQL blocks the delete via the foreign key rather than silently
            // orphaning those rows. Tell the admin instead of letting it 500.
            redirectAttributes.addFlashAttribute("error",
                    "Can't delete this train - it still has schedules linked to it. Delete or reassign those schedules first.");
        }
        return "redirect:/admin/trains";
    }

    // ===== SCHEDULES =====

    @GetMapping("/schedules")
    public String schedulesPage(Model model) {
        model.addAttribute("schedules", scheduleService.findAll());
        model.addAttribute("trains", trainRepository.findAll());
        model.addAttribute("statuses", ScheduleStatus.values());
        return "admin/schedules";
    }

    @PostMapping("/schedules")
    public String addSchedule(@RequestParam Long trainId,
                              @RequestParam String travelDate,
                              @RequestParam String departureTime,
                              @RequestParam String arrivalTime,
                              @RequestParam double firstClassFare,
                              @RequestParam(defaultValue = "0") double firstClassChildFare,
                              @RequestParam double secondClassFare,
                              @RequestParam(defaultValue = "0") double secondClassChildFare,
                              @RequestParam double thirdClassFare,
                              @RequestParam(defaultValue = "0") double thirdClassChildFare,
                              RedirectAttributes redirectAttributes) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new IllegalArgumentException("Train not found"));
        LocalDate parsedTravelDate = LocalDate.parse(travelDate);
        LocalTime parsedDepartureTime = LocalTime.parse(departureTime);
        LocalTime parsedArrivalTime = LocalTime.parse(arrivalTime);

        if (parsedTravelDate.isBefore(LocalDate.now())) {
            redirectAttributes.addFlashAttribute("error", "Travel date can't be in the past.");
            return "redirect:/admin/schedules";
        }
        if (parsedDepartureTime.equals(parsedArrivalTime)) {
            redirectAttributes.addFlashAttribute("error", "Departure and arrival time can't be the same.");
            return "redirect:/admin/schedules";
        }

        if (!trainHasClassSeatsConfigured(train)) {
            redirectAttributes.addFlashAttribute("error",
                    "Can't create a schedule for " + train.getTrainName()
                            + " - its 1st/2nd/3rd class seats aren't set up yet. Set them on the Trains page first.");
            return "redirect:/admin/schedules";
        }

        Schedule schedule = new Schedule();
        schedule.setTrain(train);
        schedule.setTravelDate(parsedTravelDate);
        schedule.setDepartureTime(parsedDepartureTime);
        schedule.setArrivalTime(parsedArrivalTime);
        schedule.setFirstClassSeats(train.getFirstClassSeats());
        schedule.setFirstClassFare(firstClassFare);
        schedule.setFirstClassChildFare(firstClassChildFare);
        schedule.setSecondClassSeats(train.getSecondClassSeats());
        schedule.setSecondClassFare(secondClassFare);
        schedule.setSecondClassChildFare(secondClassChildFare);
        schedule.setThirdClassSeats(train.getThirdClassSeats());
        schedule.setThirdClassFare(thirdClassFare);
        schedule.setThirdClassChildFare(thirdClassChildFare);

        scheduleService.save(schedule);
        return "redirect:/admin/schedules";
    }

    // A schedule's seats are copied from its train's configured 1st/2nd/3rd
    // class seats. A train whose class seats were never filled in (all 0)
    // would produce a schedule nobody can book, so that's rejected up front.
    private boolean trainHasClassSeatsConfigured(Train train) {
        return train.getFirstClassSeats() + train.getSecondClassSeats() + train.getThirdClassSeats() > 0;
    }

    @PostMapping("/schedules/{id}/update")
    public String updateSchedule(@PathVariable Long id,
                                 @RequestParam Long trainId,
                                 @RequestParam String travelDate,
                                 @RequestParam String departureTime,
                                 @RequestParam String arrivalTime,
                                 @RequestParam double firstClassFare,
                                 @RequestParam(defaultValue = "0") double firstClassChildFare,
                                 @RequestParam double secondClassFare,
                                 @RequestParam(defaultValue = "0") double secondClassChildFare,
                                 @RequestParam double thirdClassFare,
                                 @RequestParam(defaultValue = "0") double thirdClassChildFare,
                                 @RequestParam ScheduleStatus status,
                                 RedirectAttributes redirectAttributes) {
        Schedule schedule = scheduleService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found"));
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new IllegalArgumentException("Train not found"));
        LocalDate parsedTravelDate = LocalDate.parse(travelDate);
        LocalTime parsedDepartureTime = LocalTime.parse(departureTime);
        LocalTime parsedArrivalTime = LocalTime.parse(arrivalTime);

        if (parsedTravelDate.isBefore(LocalDate.now())) {
            redirectAttributes.addFlashAttribute("error", "Travel date can't be in the past.");
            return "redirect:/admin/schedules";
        }
        if (parsedDepartureTime.equals(parsedArrivalTime)) {
            redirectAttributes.addFlashAttribute("error", "Departure and arrival time can't be the same.");
            return "redirect:/admin/schedules";
        }

        // Seats aren't edited on schedules any more - they come from the train.
        // They only need to be re-copied if the admin switches this schedule to
        // a different train, and that's only safe while nobody holds a booking.
        boolean trainChanged = schedule.getTrain() == null
                || !schedule.getTrain().getId().equals(train.getId());
        if (trainChanged) {
            if (!trainHasClassSeatsConfigured(train)) {
                redirectAttributes.addFlashAttribute("error",
                        "Can't switch to " + train.getTrainName()
                                + " - its 1st/2nd/3rd class seats aren't set up yet. Set them on the Trains page first.");
                return "redirect:/admin/schedules";
            }
            boolean hasConfirmedBookings = bookingRepository.findBySchedule(schedule).stream()
                    .anyMatch(b -> b.getStatus() == BookingStatus.CONFIRMED);
            if (hasConfirmedBookings) {
                redirectAttributes.addFlashAttribute("error",
                        "Can't change the train on this schedule - it already has confirmed bookings. "
                                + "Cancel them first, or create a new schedule for the other train.");
                return "redirect:/admin/schedules";
            }
            schedule.setFirstClassSeats(train.getFirstClassSeats());
            schedule.setSecondClassSeats(train.getSecondClassSeats());
            schedule.setThirdClassSeats(train.getThirdClassSeats());
        }

        schedule.setTrain(train);
        schedule.setTravelDate(parsedTravelDate);
        schedule.setDepartureTime(parsedDepartureTime);
        schedule.setArrivalTime(parsedArrivalTime);
        schedule.setFirstClassFare(firstClassFare);
        schedule.setFirstClassChildFare(firstClassChildFare);
        schedule.setSecondClassFare(secondClassFare);
        schedule.setSecondClassChildFare(secondClassChildFare);
        schedule.setThirdClassFare(thirdClassFare);
        schedule.setThirdClassChildFare(thirdClassChildFare);
        schedule.setStatus(status);

        scheduleService.save(schedule);
        return "redirect:/admin/schedules";
    }

    @PostMapping("/schedules/{id}/delete")
    public String deleteSchedule(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            scheduleService.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            // This schedule still has bookings against it - MySQL blocks the
            // delete via the foreign key rather than silently orphaning them.
            redirectAttributes.addFlashAttribute("error",
                    "Can't delete this schedule - it still has bookings against it. Cancel or reassign those bookings first.");
        }
        return "redirect:/admin/schedules";
    }
}

