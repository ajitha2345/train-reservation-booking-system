package com.sliit.trainreservation.model;

public enum ScheduleStatus {
    ON_TIME,
    DELAYED,
    CANCELLED
}
