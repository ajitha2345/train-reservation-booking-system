package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Function 2: Seat Reservation and Booking Management
 * (Train Passengers, Reservation Officers)
 */
@Entity
@Table(name = "bookings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "passenger_id")
    private User passenger;

    @ManyToOne
    @JoinColumn(name = "schedule_id")
    private Schedule schedule;

    @Enumerated(EnumType.STRING)
    private SeatClass seatClass;

    // One booking can now cover several physical seats at once, each with
    // its own seat number and its own ticket type (Adult/Child) - see
    // BookingSeat. This replaces the old single ticketType field.
    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<BookingSeat> seats = new ArrayList<>();

    private int seatsBooked;

    private LocalDateTime bookingTime = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    private BookingStatus status = BookingStatus.CONFIRMED;

    // Unique reference shown on the e-ticket
    private String bookingReference;

    // Convenience back-reference so views can show payment status directly
    // off the booking (e.g. booking.payment.status). Payment is the owning side.
    @OneToOne(mappedBy = "booking", fetch = FetchType.EAGER)
    private Payment payment;

    // Minimum notice a passenger must give before their train departs in
    // order to still change the seats on a booking.
    public static final long EDIT_CUTOFF_DAYS = 1;

    // Minimum notice to still cancel outright. Shorter than the edit cutoff
    // on purpose: cancelling only releases a seat back to the pool (it
    // doesn't need the same planning lead time changing seats does), so a
    // same-day cancellation should still generally be possible.
    public static final long CANCEL_CUTOFF_HOURS = 2;

    // A booking can only be edited while it's still CONFIRMED and the
    // train's departure is more than EDIT_CUTOFF_DAYS away - once it's
    // within a day of departure (or already cancelled), seat changes are
    // locked out, same idea as an airline's "no changes within 24h" rule.
    public boolean isEditable() {
        if (status != BookingStatus.CONFIRMED) {
            return false;
        }
        LocalDateTime departure = departureDateTime();
        return departure != null && departure.isAfter(LocalDateTime.now().plusDays(EDIT_CUTOFF_DAYS));
    }

    // A booking can only be cancelled while it's still CONFIRMED and the
    // train's departure is more than CANCEL_CUTOFF_HOURS away.
    public boolean isCancellable() {
        if (status != BookingStatus.CONFIRMED) {
            return false;
        }
        LocalDateTime departure = departureDateTime();
        return departure != null && departure.isAfter(LocalDateTime.now().plusHours(CANCEL_CUTOFF_HOURS));
    }

    private LocalDateTime departureDateTime() {
        if (schedule == null || schedule.getTravelDate() == null || schedule.getDepartureTime() == null) {
            return null;
        }
        return LocalDateTime.of(schedule.getTravelDate(), schedule.getDepartureTime());
    }
}
