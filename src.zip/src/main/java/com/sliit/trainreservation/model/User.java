package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Covers: User Registration, Log-in/Log-out, Profile Management,
 * Role-Based Access Control (minor functions from the proposal).
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String fullName;

    @NotBlank
    @Email
    @Column(unique = true)
    private String email;

    // Stored as a BCrypt hash - never store plain text passwords (NFR: passwords hashed)
    @NotBlank
    private String password;

    private String phone;

    @Enumerated(EnumType.STRING)
    private Role role = Role.PASSENGER;

    private boolean enabled = true;
}
