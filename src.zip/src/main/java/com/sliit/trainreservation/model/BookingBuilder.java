package com.sliit.trainreservation.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DESIGN PATTERN 1: BUILDER PATTERN
 * ----------------------------------
 * A Booking has several optional/derived fields (reference number, timestamp,
 * status) set up in a fixed sequence. The Builder pattern lets BookingService
 * construct a Booking step-by-step and keeps that construction logic out of
 * the entity itself and out of the controller.
 *
 * Where it's used: BookingServiceImpl.createBooking()
 * Why: keeps Booking's constructor simple, avoids a telescoping constructor
 * as more optional fields get added later (e.g. discounts, seat class),
 * and generates the booking reference / timestamp / default status in one
 * place instead of scattering that logic across the codebase.
 */
public class BookingBuilder {

    private final Booking booking = new Booking();

    public BookingBuilder forPassenger(User passenger) {
        booking.setPassenger(passenger);
        return this;
    }

    public BookingBuilder forSchedule(Schedule schedule) {
        booking.setSchedule(schedule);
        return this;
    }

    public BookingBuilder seatClass(SeatClass seatClass) {
        booking.setSeatClass(seatClass);
        return this;
    }

    // Each BookingSeat carries its own seat number + ticket type (Adult/Child),
    // so a single booking can mix both types across the chosen seats.
    public BookingBuilder seats(List<BookingSeat> seats) {
        for (BookingSeat seat : seats) {
            seat.setBooking(booking);
        }
        booking.setSeats(seats);
        booking.setSeatsBooked(seats.size());
        return this;
    }

    public Booking build() {
        booking.setBookingTime(LocalDateTime.now());
        booking.setStatus(BookingStatus.CONFIRMED);
        booking.setBookingReference("TRS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        return booking;
    }
}
