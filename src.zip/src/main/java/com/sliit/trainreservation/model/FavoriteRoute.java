package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Now references real Station entities (like Train does) instead of
 * free-text names, so it can be matched against actual Schedules.
 */
@Entity
@Table(name = "favorite_routes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FavoriteRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "origin_station_id")
    private Station originStation;

    @ManyToOne
    @JoinColumn(name = "destination_station_id")
    private Station destinationStation;
}
