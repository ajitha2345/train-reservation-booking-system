package com.sliit.trainreservation.model;

/**
 * Maps to the stakeholders identified in the proposal:
 * PASSENGER, RESERVATION_OFFICER, SCHEDULE_MANAGER, ADMIN, SUPPORT_OFFICER
 */
public enum Role {
    PASSENGER,
    RESERVATION_OFFICER,
    SCHEDULE_MANAGER,
    ADMIN,
    SUPPORT_OFFICER
}
