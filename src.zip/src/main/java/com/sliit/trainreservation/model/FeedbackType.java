//.
package com.sliit.trainreservation.model;

/**
 * Distinguishes public star-rated feedback (visible to everyone) from a
 * private support ticket (visible only to the passenger who raised it and
 * to support staff/admin).
 */
public enum FeedbackType {
    FEEDBACK,
    TICKET
}

