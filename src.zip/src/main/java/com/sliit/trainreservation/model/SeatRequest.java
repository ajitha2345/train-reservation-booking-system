package com.sliit.trainreservation.model;

/**
 * One seat the passenger picked from the seat map, plus which ticket type
 * (Adult/Child) it should be booked as. Not a database entity - just the
 * shape the controller hands to BookingService when creating a booking.
 */
public record SeatRequest(int seatNumber, TicketType ticketType) {
}

