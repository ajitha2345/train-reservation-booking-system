package com.sliit.trainreservation.model;

/**
 * How the passenger chose to pay when booking.
 */
public enum PaymentMethod {
    CARD,
    PAY_AT_STATION
}

