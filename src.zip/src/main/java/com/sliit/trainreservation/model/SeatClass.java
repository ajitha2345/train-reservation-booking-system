package com.sliit.trainreservation.model;

public enum SeatClass {
    FIRST,
    SECOND,
    THIRD
}

