package com.sliit.trainreservation.model;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    REFUNDED
}
