package com.sliit.trainreservation.model;

public enum TicketType {
    ADULT,
    CHILD
}

