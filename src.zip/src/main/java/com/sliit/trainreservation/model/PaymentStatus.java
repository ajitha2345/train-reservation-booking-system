package com.sliit.trainreservation.model;

/**
 * PENDING: chosen "pay after coming to the station" - no money collected yet.
 * PAID:    simulated card payment went through at booking time.
 * FAILED:  simulated card payment was attempted but did not go through.
 */
public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED
}

