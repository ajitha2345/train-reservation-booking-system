package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Function 6: Train Management (System Administrators)
 */
@Entity
@Table(name = "trains")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String trainName;

    @NotBlank
    @Column(unique = true)
    private String trainNumber;

    // Kept in sync with firstClassSeats + secondClassSeats + thirdClassSeats
    // below (the admin UI computes it, the controller re-verifies it) rather
    // than derived on the fly, so existing code/queries that read totalSeats
    // directly don't need to change.
    @Positive
    private int totalSeats;

    // The train's default seat layout by class. Schedules for this train
    // don't have to use these exact numbers (a schedule's seats can be a
    // smaller subset, e.g. for a shorter/lighter working), but having them
    // here means the admin only has to work out the physical seat count
    // once per train instead of re-deriving it on every schedule.
    @PositiveOrZero
    private int firstClassSeats;

    @PositiveOrZero
    private int secondClassSeats;

    @PositiveOrZero
    private int thirdClassSeats;

    @ManyToOne
    @JoinColumn(name = "origin_station_id")
    private Station originStation;

    @ManyToOne
    @JoinColumn(name = "destination_station_id")
    private Station destinationStation;
}
