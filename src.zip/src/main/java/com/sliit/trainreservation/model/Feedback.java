//.
package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

/**
 * Function 5: Customer Support and Feedback
 */
@Entity
@Table(name = "feedback")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "passenger_id")
    private User passenger;

    @Column(length = 1000)
    private String message;

    /** Star rating given by the passenger, 1 (worst) to 5 (best). Not used for TICKET type. */
    private int rating;

    /** FEEDBACK = public rating/review. TICKET = private support question. */
    @Enumerated(EnumType.STRING)
    private FeedbackType type = FeedbackType.FEEDBACK;

    private String response;

    private boolean resolved = false;

    private LocalDateTime submittedAt = LocalDateTime.now();
}
