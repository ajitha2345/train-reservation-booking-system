package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Function 4: Train Schedule Management (Train Schedule Managers)
 * Function 1: Train Search and Schedule Viewing (Train Passengers)
 */
@Entity
@Table(name = "schedules")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "train_id")
    private Train train;

    private LocalDate travelDate;

    private LocalTime departureTime;

    private LocalTime arrivalTime;

    @Enumerated(EnumType.STRING)
    private ScheduleStatus status = ScheduleStatus.ON_TIME;

    private int firstClassSeats;
    private double firstClassFare;
    private double firstClassChildFare;

    private int secondClassSeats;
    private double secondClassFare;
    private double secondClassChildFare;

    private int thirdClassSeats;
    private double thirdClassFare;
    private double thirdClassChildFare;

    // ---- Helper methods so controllers/templates don't need a big
    //      if/else chain every time they touch a specific class ----

    public int getSeatsFor(SeatClass seatClass) {
        return switch (seatClass) {
            case FIRST -> firstClassSeats;
            case SECOND -> secondClassSeats;
            case THIRD -> thirdClassSeats;
        };
    }

    public double getFareFor(SeatClass seatClass) {
        return switch (seatClass) {
            case FIRST -> firstClassFare;
            case SECOND -> secondClassFare;
            case THIRD -> thirdClassFare;
        };
    }

    // Adult fare stays the base fare above; child fare is a separate,
    // admin-set price per class (defaults to 0 until the admin sets it).
    public double getChildFareFor(SeatClass seatClass) {
        return switch (seatClass) {
            case FIRST -> firstClassChildFare;
            case SECOND -> secondClassChildFare;
            case THIRD -> thirdClassChildFare;
        };
    }

    public double getFareFor(SeatClass seatClass, TicketType ticketType) {
        return ticketType == TicketType.CHILD ? getChildFareFor(seatClass) : getFareFor(seatClass);
    }

    public void decreaseSeatsFor(SeatClass seatClass, int seats) {
        switch (seatClass) {
            case FIRST -> firstClassSeats -= seats;
            case SECOND -> secondClassSeats -= seats;
            case THIRD -> thirdClassSeats -= seats;
        }
    }

    public void increaseSeatsFor(SeatClass seatClass, int seats) {
        switch (seatClass) {
            case FIRST -> firstClassSeats += seats;
            case SECOND -> secondClassSeats += seats;
            case THIRD -> thirdClassSeats += seats;
        }
    }

    public int getTotalAvailableSeats() {
        return firstClassSeats + secondClassSeats + thirdClassSeats;
    }
}
