package com.sliit.trainreservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * A single physical seat within a Booking. A Booking can now cover several
 * seats at once (e.g. a group of 3), and each seat has its own seat number
 * and its own ticket type (Adult/Child), so one booking can mix both.
 */
@Entity
@Table(name = "booking_seats")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingSeat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

    // Seat number within this schedule's seat class (1..capacity for that class)
    private int seatNumber;

    @Enumerated(EnumType.STRING)
    private TicketType ticketType;
}

