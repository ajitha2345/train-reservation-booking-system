package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.FavoriteRoute;
import com.sliit.trainreservation.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FavoriteRouteRepository extends JpaRepository<FavoriteRoute, Long> {
    List<FavoriteRoute> findByUser(User user);
}
