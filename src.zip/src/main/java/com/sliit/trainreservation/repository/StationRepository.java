package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Station;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StationRepository extends JpaRepository<Station, Long> {
}
