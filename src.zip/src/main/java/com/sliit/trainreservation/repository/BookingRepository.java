package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Booking;
import com.sliit.trainreservation.model.Schedule;
import com.sliit.trainreservation.model.SeatClass;
import com.sliit.trainreservation.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByPassenger(User passenger);

    // Used to work out which seat numbers are already taken for a given
    // schedule + class, so the seat map can be rendered and new picks validated.
    List<Booking> findByScheduleAndSeatClass(Schedule schedule, SeatClass seatClass);

    // All bookings against a schedule, used when an admin deletes a schedule
    // so we can purge the ones that are no longer active first.
    List<Booking> findBySchedule(Schedule schedule);
}
