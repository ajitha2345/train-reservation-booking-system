package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Booking;
import com.sliit.trainreservation.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByBooking(Booking booking);
}
