package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Train;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainRepository extends JpaRepository<Train, Long> {

    // Used by AdminController.addTrain to reject a duplicate train number
    // with a friendly message instead of letting MySQL's unique constraint
    // blow up into an error page.
    boolean existsByTrainNumberIgnoreCase(String trainNumber);

    // Used by AdminController.updateTrain - same check, but ignores the
    // train being edited so saving a train without changing its number
    // doesn't count as a duplicate of itself.
    boolean existsByTrainNumberIgnoreCaseAndIdNot(String trainNumber, Long id);
}
