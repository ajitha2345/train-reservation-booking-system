package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {

    // Used by Function 1: Train Search (exact date)
    @Query(
            "SELECT s FROM Schedule s WHERE s.train.originStation.id = :originId " +
                    "AND s.train.destinationStation.id = :destinationId AND s.travelDate = :date"
    )
    List<Schedule> searchSchedules(Long originId, Long destinationId, LocalDate date);

    // Used by Favorite Routes: all upcoming trips on a route, no date filter,
    // soonest first - so a saved route can show "book one of these" directly.
    @Query(
            "SELECT s FROM Schedule s WHERE s.train.originStation.id = :originId " +
                    "AND s.train.destinationStation.id = :destinationId AND s.travelDate >= CURRENT_DATE " +
                    "ORDER BY s.travelDate ASC, s.departureTime ASC"
    )
    List<Schedule> findUpcomingByRoute(Long originId, Long destinationId);
}
