//.
package com.sliit.trainreservation.repository;

import com.sliit.trainreservation.model.Feedback;
import com.sliit.trainreservation.model.FeedbackType;
import com.sliit.trainreservation.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByPassengerAndTypeOrderBySubmittedAtDesc(User passenger, FeedbackType type);

    List<Feedback> findByTypeOrderBySubmittedAtDesc(FeedbackType type);

    List<Feedback> findByTypeAndPassengerNotOrderBySubmittedAtDesc(FeedbackType type, User passenger);
}
