package com.sliit.trainreservation.service.payment;

import com.sliit.trainreservation.model.PaymentStatus;

/**
 * DESIGN PATTERN 2: STRATEGY PATTERN
 * ------------------------------------
 * Different payment methods (simulated card, pay-at-station, etc.) all
 * need to "process a payment" but each does it differently. Strategy lets
 * BookingService swap the algorithm at runtime based on what the passenger
 * picked, without an if/else chain, and makes it trivial to plug in a REAL
 * payment gateway later without touching any code that calls process().
 *
 * Where it's used: BookingServiceImpl.createBooking() looks the strategy up
 * by the PaymentMethod the passenger selected (bean name == enum name, see
 * SimulatedCardPaymentStrategy / PayAtStationPaymentStrategy).
 */
public interface PaymentStrategy {
    PaymentStatus process(double amount);
}

