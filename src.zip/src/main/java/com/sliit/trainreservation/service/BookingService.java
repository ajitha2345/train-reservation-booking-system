package com.sliit.trainreservation.service;

import com.sliit.trainreservation.model.Booking;
import com.sliit.trainreservation.model.PaymentMethod;
import com.sliit.trainreservation.model.SeatClass;
import com.sliit.trainreservation.model.SeatRequest;
import com.sliit.trainreservation.model.User;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface BookingService {

    Optional<Booking> findById(Long bookingId);

    // Changes which seats/ticket types a CONFIRMED booking covers, keeping
    // the same schedule and class. Only allowed while the booking is still
    // outside the edit cutoff (see Booking.isEditable()) - re-checked here
    // even though the UI already hides the option, so it can't be bypassed
    // by posting the form directly. Seat availability is re-validated the
    // same way a new booking is, excluding this booking's own current seats.
    Booking updateBookingSeats(Long bookingId, User requestingUser, List<SeatRequest> seatRequests);

    // Prevents double-booking: checks that every requested seat number is
    // still free for this schedule + class, reserves them (each seat keeps
    // its own Adult/Child ticket type), and takes a simulated payment
    // (card, or leaves it pending for pay-at-station), all in one transaction.
    Booking createBooking(User passenger, Long scheduleId, SeatClass seatClass, List<SeatRequest> seatRequests, PaymentMethod paymentMethod);

    // Lets a passenger book seats in several classes on the same schedule in
    // one go (e.g. 2 FIRST class + 3 THIRD class seats at once). Produces one
    // Booking per class (a Booking still belongs to a single class), but all
    // of them are created in a single transaction: if any class's seats can't
    // be reserved, none of them are - the passenger never ends up with only
    // part of what they asked for.
    List<Booking> createMultiClassBooking(User passenger, Long scheduleId, Map<SeatClass, List<SeatRequest>> seatRequestsByClass, PaymentMethod paymentMethod);

    List<Booking> findByPassenger(User passenger);
    void cancelBooking(Long bookingId, User requestingUser);

    // Seat-map helpers used to render the seat picker on the search results page.
    List<Integer> getOccupiedSeatNumbers(Long scheduleId, SeatClass seatClass);
    int getSeatCapacity(Long scheduleId, SeatClass seatClass);
}

