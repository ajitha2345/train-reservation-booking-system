package com.sliit.trainreservation.service;

import com.sliit.trainreservation.model.Booking;
import com.sliit.trainreservation.model.BookingStatus;
import com.sliit.trainreservation.model.Schedule;
import com.sliit.trainreservation.repository.BookingRepository;
import com.sliit.trainreservation.repository.PaymentRepository;
import com.sliit.trainreservation.repository.ScheduleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ScheduleServiceImpl implements ScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;

    public ScheduleServiceImpl(ScheduleRepository scheduleRepository,
                               BookingRepository bookingRepository,
                               PaymentRepository paymentRepository) {
        this.scheduleRepository = scheduleRepository;
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
    }

    @Override
    public List<Schedule> search(Long originStationId, Long destinationStationId, LocalDate date) {
        return scheduleRepository.searchSchedules(originStationId, destinationStationId, date);
    }

    @Override
    public List<Schedule> findUpcomingByRoute(Long originStationId, Long destinationStationId) {
        return scheduleRepository.findUpcomingByRoute(originStationId, destinationStationId);
    }

    @Override
    public List<Schedule> findAll() {
        return scheduleRepository.findAll();
    }

    @Override
    public Optional<Schedule> findById(Long id) {
        return scheduleRepository.findById(id);
    }

    @Override
    public Schedule save(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        Schedule schedule = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found"));

        // Cancelled/refunded bookings are kept around for passenger history,
        // but they still hold a foreign key to this schedule. Once the admin
        // is deleting the schedule itself, those inactive bookings (and their
        // payment rows) no longer need to exist, so purge them first. Any
        // still-CONFIRMED booking is left alone, so the delete below still
        // fails safely (via the FK constraint) if real, active bookings remain.
        List<Booking> bookings = bookingRepository.findBySchedule(schedule);
        for (Booking booking : bookings) {
            if (booking.getStatus() == BookingStatus.CONFIRMED) {
                continue;
            }
            paymentRepository.findByBooking(booking).ifPresent(paymentRepository::delete);
            bookingRepository.delete(booking);
        }

        scheduleRepository.deleteById(id);
    }
}
