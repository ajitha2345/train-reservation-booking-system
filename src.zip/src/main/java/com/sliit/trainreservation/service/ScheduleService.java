package com.sliit.trainreservation.service;

import com.sliit.trainreservation.model.Schedule;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ScheduleService {
    List<Schedule> search(Long originStationId, Long destinationStationId, LocalDate date);
    List<Schedule> findUpcomingByRoute(Long originStationId, Long destinationStationId);
    List<Schedule> findAll();
    Optional<Schedule> findById(Long id);
    Schedule save(Schedule schedule);
    void deleteById(Long id);
}

