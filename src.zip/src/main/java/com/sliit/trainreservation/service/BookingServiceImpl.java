package com.sliit.trainreservation.service;

import com.sliit.trainreservation.model.*;
import com.sliit.trainreservation.repository.BookingRepository;
import com.sliit.trainreservation.repository.PaymentRepository;
import com.sliit.trainreservation.repository.ScheduleRepository;
import com.sliit.trainreservation.service.payment.PaymentStrategy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final ScheduleRepository scheduleRepository;
    private final PaymentRepository paymentRepository;

    // Strategy pattern - see service/payment package. Spring injects every
    // PaymentStrategy bean here keyed by its bean name, which is set to match
    // PaymentMethod.name() (e.g. "CARD", "PAY_AT_STATION"), so the right
    // strategy can be looked up directly from the method the passenger picked.
    private final Map<String, PaymentStrategy> paymentStrategies;

    public BookingServiceImpl(BookingRepository bookingRepository,
                              ScheduleRepository scheduleRepository,
                              PaymentRepository paymentRepository,
                              Map<String, PaymentStrategy> paymentStrategies) {
        this.bookingRepository = bookingRepository;
        this.scheduleRepository = scheduleRepository;
        this.paymentRepository = paymentRepository;
        this.paymentStrategies = paymentStrategies;
    }

    @Override
    public Optional<Booking> findById(Long bookingId) {
        return bookingRepository.findById(bookingId);
    }

    @Override
    @Transactional
    public Booking updateBookingSeats(Long bookingId, User requestingUser, List<SeatRequest> seatRequests) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));

        if (!booking.getPassenger().getId().equals(requestingUser.getId())) {
            throw new SecurityException("You can only edit your own bookings.");
        }
        if (!booking.isEditable()) {
            throw new IllegalStateException(
                    "This booking can no longer be edited - changes must be made at least "
                            + Booking.EDIT_CUTOFF_DAYS + " day(s) before departure.");
        }
        if (seatRequests == null || seatRequests.isEmpty()) {
            throw new IllegalArgumentException("Select at least one seat.");
        }

        Schedule schedule = booking.getSchedule();
        SeatClass seatClass = booking.getSeatClass();
        int oldCount = booking.getSeatsBooked();

        // This booking's own seats are allowed to be re-picked (e.g. kept as
        // they are, or swapped for a different ticket type), so they're
        // excluded from the "already taken" set before re-validating.
        Set<Integer> occupied = new HashSet<>(occupiedSeatNumbers(schedule, seatClass));
        for (BookingSeat currentSeat : booking.getSeats()) {
            occupied.remove(currentSeat.getSeatNumber());
        }

        Set<Integer> requestedNumbers = new HashSet<>();
        for (SeatRequest request : seatRequests) {
            if (occupied.contains(request.seatNumber())) {
                throw new IllegalStateException("Seat " + request.seatNumber() + " is already taken. Please pick another seat.");
            }
            if (!requestedNumbers.add(request.seatNumber())) {
                throw new IllegalArgumentException("Seat " + request.seatNumber() + " was selected more than once.");
            }
        }

        int newCount = seatRequests.size();
        int extraSeatsNeeded = newCount - oldCount;
        if (extraSeatsNeeded > 0 && schedule.getSeatsFor(seatClass) < extraSeatsNeeded) {
            throw new IllegalStateException("Not enough " + seatClass + " class seats available to add more.");
        }

        // Replace the booking's seats in place (not booking.setSeats(...)) so
        // Hibernate's orphanRemoval actually deletes the old BookingSeat rows.
        List<BookingSeat> newSeats = new ArrayList<>();
        double amount = 0.0;
        for (SeatRequest request : seatRequests) {
            BookingSeat seat = new BookingSeat();
            seat.setSeatNumber(request.seatNumber());
            seat.setTicketType(request.ticketType());
            seat.setBooking(booking);
            newSeats.add(seat);
            amount += schedule.getFareFor(seatClass, request.ticketType());
        }
        booking.getSeats().clear();
        booking.getSeats().addAll(newSeats);
        booking.setSeatsBooked(newCount);

        if (extraSeatsNeeded > 0) {
            schedule.decreaseSeatsFor(seatClass, extraSeatsNeeded);
        } else if (extraSeatsNeeded < 0) {
            schedule.increaseSeatsFor(seatClass, -extraSeatsNeeded);
        }
        scheduleRepository.save(schedule);

        // Keep the existing payment record, just reflect the new amount -
        // editing doesn't re-run the payment strategy or change how/whether
        // the passenger has already paid.
        if (booking.getPayment() != null) {
            booking.getPayment().setAmount(amount);
            paymentRepository.save(booking.getPayment());
        }

        return bookingRepository.save(booking);
    }

    @Override
    @Transactional // keeps the occupied-seat check + decrement atomic -> prevents double-booking
    public Booking createBooking(User passenger, Long scheduleId, SeatClass seatClass, List<SeatRequest> seatRequests, PaymentMethod paymentMethod) {
        return bookOneClass(passenger, scheduleId, seatClass, seatRequests, paymentMethod);
    }

    @Override
    @Transactional // one transaction across every class requested, so a failure on any class rolls all of them back
    public List<Booking> createMultiClassBooking(User passenger, Long scheduleId, Map<SeatClass, List<SeatRequest>> seatRequestsByClass, PaymentMethod paymentMethod) {
        if (seatRequestsByClass == null || seatRequestsByClass.isEmpty()) {
            throw new IllegalArgumentException("Select at least one seat.");
        }

        List<Booking> bookings = new ArrayList<>();
        for (Map.Entry<SeatClass, List<SeatRequest>> entry : seatRequestsByClass.entrySet()) {
            bookings.add(bookOneClass(passenger, scheduleId, entry.getKey(), entry.getValue(), paymentMethod));
        }
        return bookings;
    }

    // Shared by both the single-class and multi-class entry points above.
    // Not @Transactional itself - it always runs inside whichever public
    // method's transaction called it, which is what lets the multi-class
    // path treat several of these calls as one all-or-nothing unit of work.
    private Booking bookOneClass(User passenger, Long scheduleId, SeatClass seatClass, List<SeatRequest> seatRequests, PaymentMethod paymentMethod) {
        if (seatRequests == null || seatRequests.isEmpty()) {
            throw new IllegalArgumentException("Select at least one seat.");
        }

        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found."));

        int requestedCount = seatRequests.size();
        if (schedule.getSeatsFor(seatClass) < requestedCount) {
            throw new IllegalStateException("Not enough " + seatClass + " class seats available.");
        }

        // Re-check against the current occupied set here (inside the transaction)
        // so two passengers can't grab the same seat number at the same time.
        Set<Integer> occupied = new HashSet<>(occupiedSeatNumbers(schedule, seatClass));
        Set<Integer> requestedNumbers = new HashSet<>();
        for (SeatRequest request : seatRequests) {
            if (occupied.contains(request.seatNumber())) {
                throw new IllegalStateException("Seat " + request.seatNumber() + " was just taken by someone else. Please pick another seat.");
            }
            if (!requestedNumbers.add(request.seatNumber())) {
                throw new IllegalArgumentException("Seat " + request.seatNumber() + " was selected more than once.");
            }
        }

        List<BookingSeat> bookingSeats = new ArrayList<>();
        double amount = 0.0;
        for (SeatRequest request : seatRequests) {
            BookingSeat seat = new BookingSeat();
            seat.setSeatNumber(request.seatNumber());
            seat.setTicketType(request.ticketType());
            bookingSeats.add(seat);
            amount += schedule.getFareFor(seatClass, request.ticketType());
        }

        // Builder pattern - see model/BookingBuilder.java
        Booking booking = new BookingBuilder()
                .forPassenger(passenger)
                .forSchedule(schedule)
                .seatClass(seatClass)
                .seats(bookingSeats)
                .build();

        schedule.decreaseSeatsFor(seatClass, requestedCount);
        scheduleRepository.save(schedule);
        booking = bookingRepository.save(booking);

        PaymentStrategy strategy = paymentStrategies.get(paymentMethod.name());
        PaymentStatus status = strategy.process(amount);

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setAmount(amount);
        payment.setMethod(paymentMethod);
        payment.setStatus(status);
        paymentRepository.save(payment);
        booking.setPayment(payment); // keep the in-memory booking in sync for the confirmation view

        return booking;
    }

    @Override
    public List<Integer> getOccupiedSeatNumbers(Long scheduleId, SeatClass seatClass) {
        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found."));
        return occupiedSeatNumbers(schedule, seatClass);
    }

    @Override
    public int getSeatCapacity(Long scheduleId, SeatClass seatClass) {
        Schedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found."));
        // Capacity = seats still free + seats already held by active bookings.
        return schedule.getSeatsFor(seatClass) + occupiedSeatNumbers(schedule, seatClass).size();
    }

    // Seat numbers currently held by non-cancelled bookings for this schedule + class.
    // A cancelled booking's seats go back into the free pool automatically since
    // they're excluded here (cancelBooking() also restores the free-seat count).
    private List<Integer> occupiedSeatNumbers(Schedule schedule, SeatClass seatClass) {
        List<Integer> numbers = new ArrayList<>();
        for (Booking booking : bookingRepository.findByScheduleAndSeatClass(schedule, seatClass)) {
            if (booking.getStatus() == BookingStatus.CANCELLED) {
                continue;
            }
            for (BookingSeat seat : booking.getSeats()) {
                numbers.add(seat.getSeatNumber());
            }
        }
        return numbers;
    }

    @Override
    public List<Booking> findByPassenger(User passenger) {
        return bookingRepository.findByPassenger(passenger);
    }

    @Override
    @Transactional
    public void cancelBooking(Long bookingId, User requestingUser) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));

        if (!booking.getPassenger().getId().equals(requestingUser.getId())) {
            throw new SecurityException("You can only cancel your own bookings.");
        }
        if (!booking.isCancellable()) {
            throw new IllegalStateException(
                    "This booking can no longer be cancelled - cancellations must be made at least "
                            + Booking.CANCEL_CUTOFF_HOURS + " hour(s) before departure.");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        Schedule schedule = booking.getSchedule();
        schedule.increaseSeatsFor(booking.getSeatClass(), booking.getSeatsBooked());

        scheduleRepository.save(schedule);
        bookingRepository.save(booking);
    }
}
