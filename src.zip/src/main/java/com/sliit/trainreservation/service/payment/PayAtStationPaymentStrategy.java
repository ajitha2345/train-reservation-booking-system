package com.sliit.trainreservation.service.payment;

import com.sliit.trainreservation.model.PaymentStatus;
import org.springframework.stereotype.Component;

/**
 * "Pay after coming to the station" option - no money is collected at
 * booking time, so the payment simply stays PENDING until staff mark it
 * paid at the station counter. Bean name matches PaymentMethod.PAY_AT_STATION
 * so BookingServiceImpl can look it up by the method the passenger selected.
 */
@Component("PAY_AT_STATION")
public class PayAtStationPaymentStrategy implements PaymentStrategy {

    @Override
    public PaymentStatus process(double amount) {
        return PaymentStatus.PENDING;
    }
}

