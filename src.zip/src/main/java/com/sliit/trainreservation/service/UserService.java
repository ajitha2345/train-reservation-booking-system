package com.sliit.trainreservation.service;

import com.sliit.trainreservation.model.User;

public interface UserService {
    User register(User user);
    User findByEmail(String email);
}
