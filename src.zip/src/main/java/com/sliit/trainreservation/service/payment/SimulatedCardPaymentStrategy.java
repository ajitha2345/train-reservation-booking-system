package com.sliit.trainreservation.service.payment;

import com.sliit.trainreservation.model.PaymentStatus;
import org.springframework.stereotype.Component;

/**
 * Simulated payment strategy - no real bank integration, per project scope.
 * Always succeeds unless the amount is invalid, so the team can demo the
 * full booking -> payment -> ticket flow without needing a real gateway.
 * Bean name matches PaymentMethod.CARD so BookingServiceImpl can look it up
 * by the method the passenger selected.
 */
@Component("CARD")
public class SimulatedCardPaymentStrategy implements PaymentStrategy {

    @Override
    public PaymentStatus process(double amount) {
        return amount > 0 ? PaymentStatus.PAID : PaymentStatus.FAILED;
    }
}

